<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
    <div class="container d-flex justify-content-center">

        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="/"> Home </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/upload"> Upload </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/edit"> Edit </a>
            </li>
        </ul>

    </div>
</nav>
