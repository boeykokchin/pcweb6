<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Pokemons</title>
    <link rel="icon" type="image/png" href="img/favicon.png">
    <link rel="stylesheet" href="style.css" type="text/css">
    <link rel="stylesheet"
        href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script
        src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js">
    </script>
    <script
        src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js">
    </script>
    <script
        src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js">
    </script>
    <script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js">
    </script>

</head>

<body>
    <?php include("navbar.php"); ?>

    <div class="container">
        <div class="row">
            <div class="col-3" id="pname">
                
                <h1><img class="playericon" src="img/favicon.png" alt=""></h1>
                <br>
                <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h4> <a
                        href='/<?php echo e($player->PlayerName); ?>'><?php echo e($player->PlayerName); ?></a>
                </h4>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-6">
                <?php if(@isset($name)): ?>
                <h2><?php echo e($name); ?></h2>
                <p><?php echo e($desc->Description); ?><br></p>
                <?php else: ?>
                <h2>Choose a Pokemon, or add a Pokemon!</h2>
                <?php endif; ?>
            </div>
            <div class="col-3" id="picpic">
                <?php if(@isset($name)): ?>
                <form method="post" action="<?php echo e(route('deletePlayer')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="btns">
                        <input type="button" value="Hide Pic" id="hidebtn"
                            onclick="changeVis()">
                        <input type="submit" name="delete"
                            value="Delete Pokemon">
                    </div>
                    <img id="hide"
                        src="<?php echo e(asset('uploads/player/' . $desc->Image)); ?>"
                        alt="Image" height="200">
                    <textarea style="visibility: hidden;"
                        name="nameDEL"><?php echo e($name); ?></textarea>
                </form>
                <?php else: ?>

                <?php endif; ?>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        // function changeVis() {
            //     document.getElementById("hide").style.visibility = "hidden";
            //     document.getElementById("hidebtn").value = "Show Pic";
            //     document.getElementById("hidebtn").onclick = function() { swapVis(); };
            // }

            // function swapVis() {
            //     document.getElementById("hide").style.visibility = "visible";
            //     document.getElementById("hidebtn").value = "Hide Pic";
            //     document.getElementById("hidebtn").onclick = function() { changeVis(); };
            // }

            var show = true;
            $(document).ready(function(){
                if(show){
                  $("input").click(function(){
                    $("img").toggle();
                    document.getElementById("hidebtn").value = "Show Pic";
                    var show = false;
                  });
                }else{
                    $("input").click(function(){
                    $("img").toggle();
                    document.getElementById("hidebtn").value = "Hide Pic";
                    var show = true;
                  });
                }
            });
    </script>
</body>

</html>
<?php /**PATH /home/boeykokchin/pcweb/5/smu-pcweb5-final/laravel_blog/resources/views/welcome.blade.php ENDPATH**/ ?>