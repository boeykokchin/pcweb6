$(document).ready(function(){
    $("img")
  .fadeIn({duration: 500})
  .css("display", "none")
  .slideDown(700);
});
