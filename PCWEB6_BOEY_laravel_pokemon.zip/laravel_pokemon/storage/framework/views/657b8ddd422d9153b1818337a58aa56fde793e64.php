<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Pokemon - Edit</title>
    <link rel="icon" type="image/png" href="img/favicon.png">
    <link rel="stylesheet" href="<?php echo asset('style.css')?>"
        type="text/css">
    <link rel="stylesheet"
        href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script
        src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js">
    </script>
    <script
        src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js">
    </script>
    <script
        src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js">
    </script>
    <script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js">
    </script>

</head>

<body>
    <?php include("navbar.php"); ?>

    <div class="container">
        <div class="row">
            <div class="col-3">
                
                <h1><img class="playericon" src="img/favicon.png" alt=""></h1>
                <br>
                <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h4> <a
                        href='/edit/<?php echo e($player->PlayerName); ?>'><?php echo e($player->PlayerName); ?></a>
                </h4>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-9">
                <?php if(@isset($name)): ?>
                <form method="post" enctype="multipart/form-data"
                    action="<?php echo e(route('editPlayer')); ?>">
                    <?php echo csrf_field(); ?>
                    <h2>Pokemon</h2>
                    <input class="player" type="text" name="player"
                        value="<?php echo e($name); ?>">
                    <h2>Characteristics</h2>
                    <textarea class="desc"
                        name="description"><?php echo e($desc->Description); ?></textarea>
                    <input type="file" name="image">
                    <input type="submit" value="Submit" name="upload">
                    <textarea name="oldplayer"
                        style="visibility: hidden;"><?php echo e($name); ?></textarea>
                </form>
                <?php else: ?>
                <h2>Choose a Pokemon to edit!</h2>
                <?php endif; ?>
            </div>
        </div>
    </div>

</body>

</html>
<?php /**PATH /home/boeykokchin/pcweb/5/smu-pcweb5-final/laravel_blog/resources/views/edit.blade.php ENDPATH**/ ?>